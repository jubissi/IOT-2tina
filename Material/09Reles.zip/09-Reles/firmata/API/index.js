var express = require('express');
var app = express();
var five = require("johnny-five");
var board = new five.Board();
var relay = null;

board.on("ready", function() {
  relay = new five.Relay(8);
  this.repl.inject({
    relay: relay
  });
});

app.get('/ligar', function (req, res) {
  res.send('Ligado');

  if (relay != null) {
    relay.on();
  }
});

app.get('/desligar', function (req, res) {
  res.send('Desligado');

  if (relay != null) {
    relay.off();
  }
});

app.listen(3000, function () {
  console.log('app listening on port 3000!');
});
